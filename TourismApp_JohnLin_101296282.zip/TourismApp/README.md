Student Name: John Lin
Student Number: 101296282

* Tokyo 2020 App will install as `TourismApp`
* By default, an Admin user is added during the first app opening:
  * username: admin
  * password: admin
* When adding Attractions, these images are predefined, simply enter the names into the image_path when adding attractions:
  * Tokyo Tower : img_tokyo_tower
  * Sky Tree: img_sky_tree
  * Akihabara: img_akihabara
  * Life Sized Gundam Statue: img_unicorn_gundam_statue
  * Sensō-ji: img_senso_ji
  * Meiji Jingu: img_meiji_jingu
  * Ueno Onshi Park: img_ueno_onshi_park
