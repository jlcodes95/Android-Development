/* -----------------------------------
 * John Lin
 * 101296282
 * ----------------------------------- */
package com.example.rydeapp;

public class CredentialException extends  Exception{

    public CredentialException(String msg){
        super(msg);
    }


}
