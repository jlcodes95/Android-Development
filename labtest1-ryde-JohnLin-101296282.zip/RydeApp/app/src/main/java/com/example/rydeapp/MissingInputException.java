/* -----------------------------------
 * John Lin
 * 101296282
 * ----------------------------------- */
package com.example.rydeapp;

public class MissingInputException extends Exception {

    public MissingInputException(String msg){
        super(msg);
    }
}
