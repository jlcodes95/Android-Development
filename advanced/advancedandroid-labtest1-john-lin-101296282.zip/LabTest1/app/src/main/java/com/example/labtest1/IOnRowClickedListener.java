package com.example.labtest1;

public interface IOnRowClickedListener {
    void onRowClicked(int position);
}

